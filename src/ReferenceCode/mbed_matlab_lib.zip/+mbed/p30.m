function val = p30
val = mbed.PinName('p30',30);
