function val = p8
val = mbed.PinName('p8',8);
