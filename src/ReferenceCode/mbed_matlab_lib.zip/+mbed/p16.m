function val = p16
val = mbed.PinName('p16',16);
