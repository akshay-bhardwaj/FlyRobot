function val = p23
val = mbed.PinName('p23',23);
