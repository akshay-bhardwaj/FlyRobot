function val = p19
val = mbed.PinName('p19',19);
