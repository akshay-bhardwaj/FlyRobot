function val = LED3
val = mbed.PinName('LED3',3);
