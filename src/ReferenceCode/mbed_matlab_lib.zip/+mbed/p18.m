function val = p18
val = mbed.PinName('p18',18);
