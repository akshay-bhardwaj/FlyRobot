function val = p22
val = mbed.PinName('p22',22);
