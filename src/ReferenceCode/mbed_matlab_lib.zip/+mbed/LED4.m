function val = LED4
val = mbed.PinName('LED4',4);
