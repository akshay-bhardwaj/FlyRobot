function val = p25
val = mbed.PinName('p25',25);
