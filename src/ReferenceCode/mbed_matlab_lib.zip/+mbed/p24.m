function val = p24
val = mbed.PinName('p24',24);
