function val = p17
val = mbed.PinName('p17',17);
