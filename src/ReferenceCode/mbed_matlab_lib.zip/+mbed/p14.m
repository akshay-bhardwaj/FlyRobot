function val = p14
val = mbed.PinName('p14',14);
