function val = p27
val = mbed.PinName('p27',27);
