function val = p10
val = mbed.PinName('p10',10);
