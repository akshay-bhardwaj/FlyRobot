function val = p7
val = mbed.PinName('p7',7);
