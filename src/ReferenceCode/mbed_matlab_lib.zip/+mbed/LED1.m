function val = LED1
val = mbed.PinName('LED1',1);
