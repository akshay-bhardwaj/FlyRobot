function val = p11
val = mbed.PinName('p11',11);
