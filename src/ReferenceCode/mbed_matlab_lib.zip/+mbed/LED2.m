function val = LED2
val = mbed.PinName('LED2',2);
