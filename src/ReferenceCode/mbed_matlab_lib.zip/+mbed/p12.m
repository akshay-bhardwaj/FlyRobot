function val = p12
val = mbed.PinName('p12',12);
