function val = p5
val = mbed.PinName('p5',5);
