function val = p6
val = mbed.PinName('p6',6);
