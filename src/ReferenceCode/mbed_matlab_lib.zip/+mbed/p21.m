function val = p21
val = mbed.PinName('p21',21);
