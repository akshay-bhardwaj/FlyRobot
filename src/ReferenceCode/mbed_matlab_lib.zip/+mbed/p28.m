function val = p28
val = mbed.PinName('p28',28);
