function val = p26
val = mbed.PinName('p26',26);
