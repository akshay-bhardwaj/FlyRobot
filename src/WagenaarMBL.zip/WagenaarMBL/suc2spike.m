function suc2spike
error('The function SUC2SPIKE has been renamed DETECTSPIKE. Please update your code.');